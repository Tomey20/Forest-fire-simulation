import random
from generation import Graph
class Landpatch:
    """
    Author: Hoang Nguyen Le
    """
    def __init__(self, g, ID) -> None:
        self.g = g                                      #instance of Graph
        self.ID = ID                                    #Node number
        self.neighbor = self.g._neighbours[self.ID]     #the instance neighbouring nodes
        
    #getters
    def getter_node(self):
        return self.node

    def getter_patch(self):
        return self.patch

    def getter_neighbor(self):
        return self.neighbor

class Treepatch(Landpatch):
    def __init__(self, g, ID, Respawn:float = 0.01, AutoCombustion:float= 0.3, Transmission:float = 0.3):#node:int,
        super().__init__(g, ID)
        self.treestat = random.randint(50,250)          #treepatches stat. starting value between 50 and 250
        self.mark = False                               #mark used for 
        self.ablaze = False                             #is the patch on fire
        self.AutoCombustion = AutoCombustion            #p of a patch igniting on its own
        self.Transmission = Transmission                #p of a patch on fire transmitting the fire to a neighbouring Treepatch
        self.Respawn = Respawn                          #p of a Rockpatch mutating into a Treepatch
        self.neighbor = self.g._neighbours[self.ID]     #neighbours of a given node

    #Getters       
    def getter_ablaze(self):
        return self.ablaze                              #Get the ablaze status

    def getter_stat(self):
        return self.treestat                            #Get the stat of the tree
    
    def getter_mark(self):
        return self.mark                                #Get the mark attibutes

    #setter
    def setter_marker(self, marking:bool):
        self.mark = marking                             #Set the mark
    
    #setters
     
    def setter_ablaze(self, firestatus:bool):
         self.ablaze = firestatus                                            #can set the ablaze attibute

    def setter_stat(self, change:int):
        """
        sets the treestat value. max value is 256, and value above will be set to 256
        The change value depend on the ablaze:bool. True decreases the stat with 20 and False increases it with 10
        """ 
        if self.treestat + change > 256:                #If the stat is above the max value
            change = 256                                #The maxvalue is set to 256
        elif self.treestat + change <= 256:             #If the stat is within the appororeate range
            change = self.treestat + change
        self.treestat = change

    def auto_ignition(self):
        """
        Node as trees can autocombust with the probabilaty of combust (default = 30%)

        argument:
        combust - float value that provide the probabilaty to set mark to True
        """
        if isinstance(self, Treepatch) and self.getter_ablaze() == False and random.random() <= self.AutoCombustion:    #If statement for the instance is a treepatch, not ablaze, and a probabilaty
            self.setter_marker(True)                                                                        #satisfacory of the if statement results in setting mark to true

    def wildfire_transmission(self):
        """
        Node transmitting mark to other treepatch instance. (default = 30%)
        
        argument:
        - transmission: loat value that provide the probabilaty to set mark to True for neighboring treeptaches
        """
        if self.ablaze == True: #TODO is this defined
            for neighbour in self.neighbor:
                neighbour_patch = self.g.get_node_patch(neighbour)
                if isinstance(neighbour_patch,Treepatch) and neighbour_patch.getter_ablaze() == False and random.random() <= self.Transmission: 
                    neighbour_patch.setter_marker(True)

    def update_land(self):
        """
        Update the trees stat during evolutaionary step depending in the ablaze status 
        """
        if not self.getter_ablaze():                                            #ablaze == True -> += 10 in stat
            self.setter_stat(10)
        elif self.getter_ablaze():                                              #ablaze == Flase -> -=20 in stat
            self.setter_stat(-20)
            
    def tree_mutation(self):
        """
        mutates the trees into rocks if their stat hits below 0

        return:
        sets the patch to "rock" when stat is <0
        """
        if self.getter_stat() < 0:                                              #tree's stat is 0 or lower, do the following:
            self.g.set_node_patch(self.ID, Rockpatch(self.g, self.ID, self.Respawn, self.AutoCombustion, self.Transmission))                             #mutate the patch into a rockpatch 

class Rockpatch(Landpatch):
    def __init__(self, g, ID, respawn:float = 0.01, AutoCombustion:float = 0.3, Transmission:float = 0.3):
        super().__init__(g, ID)
        self.Respawn = respawn
        self.AutoCombustion = AutoCombustion
        self.Transmission = Transmission

    def rock_mutation(self):
        """
        Every patch: "rock" have a probabillity of mutating into patch: tree with a probabillity of 0.01
        """
        if isinstance(self, Rockpatch) and random.random() <= self.Respawn:
            self.g.set_node_patch(self.ID, Treepatch(self.g, self.ID, self.Respawn, self.AutoCombustion, self.Transmission))                                      #mutate rock to tree
