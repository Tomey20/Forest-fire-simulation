#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 18 14:05:54 2023

@author: Sofie

This module contains the firefighter class.
This class allows for the generation of a firefighter 

The firefighter does not alter the damage the fire can deal, the fireman alters
the length of time at which ablaze can be true 
fire is considered a seperate stat, if ablaze == True, visualiser needs to look 
at fire stat for colour, if fire stat == 0. ablaze == False 
"""

import random 
from generation import Graph
from class_landscape import Landpatch, Treepatch, Rockpatch


#Class Firefighter
class Firefighter():
    """
    With the setup of this class, it requires other classes, Graph and Landpatch, that 
    contains information about each node and its settings.
    """  
    
    def __init__(self, graph):
        self._graph = graph
        self._level = 1   

        locations = self._graph.get_nodes()
        choice = random.choice(list(locations))        
        self._location = choice           #placeholder, firefighters will be assigned a location by the subclass
        self._fire_extinguish_stat = 0

#Getters
    """
    Allows other functions to access and change the level attribute, without
    overriding the actual code.
    """

    def get_level(self) -> int:
        return self._level
    
    def get_location(self) -> int:
        return self._location
    
    def get_fire_extinguish_stat(self) -> int:
        return self._fire_extinguish_stat

#Setters
    """
    Sets class attributes to a new value.
    """
    def set_level(self, new_level:int) -> None:
        """
        Level must be below fire level, default 3. 
        """
        self._level = new_level
         
    def set_location(self, new_location:int) -> None:
        """
        Places all firefighters randomly on the graph before the simulation begins.
        
        Precondition: 
        all locations chosen must be an instance of a landpatch class
        """
        if new_location in self._graph.get_nodes_instance():
            self._location = new_location
        else:
            raise ValueError("Location must be a in the graph")
    
    def set_fire_extinguish_stat(self, new_extinguish_stat:int) -> None:
        if new_extinguish_stat not in [0, 1, 2, 3]: #accepted stats 
                    raise ValueError("Invalid fire extinguish stat")
        self._fire_extinguish_stat = new_extinguish_stat
            
#Methods
#graph is the graph we are working on

    def move_to_next(self) -> None:
        """
        Describes possible actions for a fireman. 
        
        The actions are split based on priority into;
        Extinguish fire: if the patch the firefighter is on, it should stay and 
        extinguish the fire
        Move_to_ablaze:
        if a neighbour is ablaze, he should move to the neighbour
        If none of the above, he should move to any given neighbour.
        
        Preconditions:
        This function requires a graph whose nodes have all been initialised 
        into an instance of a landpatch class. 
        """
        #location of firefighter is also the node ID used in Class Landscape
        location = self._location
        patch = self._graph.get_node_patch(location)
        
        neighbours_ablaze = []
        
        for neighbour in patch.getter_neighbor(): #check all neighbours to this patch
            nodepatch = self._graph.get_node_patch(neighbour) #ensure that the programme is dealing with a patch
            if isinstance(nodepatch, Treepatch) and nodepatch.getter_ablaze():
                neighbours_ablaze.append(neighbour)
       
        #if current patch ablaze, stay and extinguish
        if isinstance(patch, Treepatch) and patch.getter_ablaze() == True:
            self.fire_extinguish()
        
        #A neighbour is on fire
        elif len(neighbours_ablaze) > 0: #there could be more than one neighbour on fire, pick one at random
            choice = random.choice(neighbours_ablaze)
            self._location = choice          #move to new location
    
        #if none of the above, move to random neighbour 
        else:
            choice = random.choice(list(patch.getter_neighbor()))
            self._location = choice
            
    
    def fire_extinguish(self) -> None:
        """
        Firefighter are able to set ablaze to false.
        The evolutionary steps of setting ablaze to False depends on the level of 
        the firefighter.
        """
        #add level to fire_extinguish_stat
        self._fire_extinguish_stat = self._fire_extinguish_stat + self._level
        
        #compare if fire_extinguish_stat to max val of fire 
        if self._fire_extinguish_stat >= 3:           
            patch = self._graph.get_node_patch(self._location)
            patch.setter_ablaze(False)           # set the ablaze attibute   
            self._fire_extinguish_stat = 0          # reset fire_extiontion_stacks 
                
    
class FireCrew(Firefighter):
    
    def __init__(self, graph, number:int, ave_skill:int = 1):
        """
        Makes a firecrew, which is a list of all firefighter instances.
        
        Attributes:
        _crew: the list of firefighter instances
        _ave_skills: the average skill of the crew, this is set by user
        _locations: a list containing the current location of all 
           firefighters
        _graph: the graph the firefighters are moving on, all nodes of the 
        graph must be instances of the class landpatch of its child classes.
        """
        self._graph = graph #this graph is a Graph object
        
        if number < 0 or number > len(self._graph.get_nodes()):
            raise ValueError ("Invalid number of firefighters") #should never happen, user interface should have caught these 
        
        super().__init__(graph)                                 #initialise parent class
        crew = [Firefighter(graph) for _ in range(number)]      
        self._crew = crew
        
        occupied = []
        not_occupied = list(self._graph.get_nodes()) #initially, no nodes a are occupied
        
        for firefighter in self._crew:
            current_location = firefighter.get_location()
           
            if current_location not in occupied:     #there is not already a firefighter assigned
                occupied.append(current_location)
                not_occupied.remove(current_location)
                
            elif current_location in occupied:      #location already has a firefighter, location in occupied
                new_location = random.choice(not_occupied)
                firefighter.set_location(new_location) 
                occupied.append(new_location)
                
                if current_location in not_occupied:
                    not_occupied.remove(new_location)
                
        self._locations = occupied
        
        self.ave_skill = ave_skill      
        
        
    #Getters
    """
    Allows access to class attributes
    """
    def get_crew(self) -> list:
        return self._crew
    
    def get_ave_skill(self) -> int:
        return self.ave_skill
    
    def get_locations(self) -> list[int]:
        return self._locations
        
#Setters
    """
    Allows altering of class attributes.
    """
    
    def set_ave_skill(self, new_ave_skill:int) -> None:
        if new_ave_skill not in [1, 2, 3]:
            raise ValueError ("Invalid average skill level") #this should never be relevant, user interface should have caught it 
        self.ave_skill = new_ave_skill
        self.set_skills()
        
    def update_locations(self) -> None:
        """
        Obtains current location for each firefighter in _crew and sets the 
        attribute _locations to the current locations.
        """
        current_locations = [firefighter.get_location() for firefighter in self._crew]
        self._locations = current_locations
    
        
    def set_skills(self) -> None:
        """
        Sets the skill of all firefighters in the crew, based on a user chosen
        average skill level. The average level, is roughly kept.
        
        Local variables:
        number_of_firefighters = the number of firefighters in the crew
        target_sum = based on the average skill level, what will the sum be
        initial_skill = a list of random numbers
        current_sum = sum of initial skill, indicates how far off the current "skills" are
            
        adjustment = the total amount of adjustment to do for the current_sum to match target_sum
        adjustment_per_skill = the amount each "skill" from initial_skill will need to be adjusted to meet target_sum
        This is an average, which means the range of skills will not differ, only the values
            
        adjust_skills = a list of adjusted skill
        """
        #Determine desired sum of list, based on desired average skill level
        number_of_firefighters = len(self._crew)
        target_sum = self.ave_skill * number_of_firefighters
        
        #Generate a initial skill for each firefighter
        initial_skill = [random.randint(1, 3) for _ in range(number_of_firefighters)] 
        
        #How much should initial skills be adjusted to meet target
        current_sum = sum(initial_skill)
        adjustment = target_sum - current_sum
        adjustment_per_skill = adjustment // number_of_firefighters #how much should each skill be offset by for the sum to be roughly the desired sum
        
        #adjust all skills accordingly
        adjust_skills = [skill + adjustment_per_skill for skill in initial_skill]
        
        #Apply skill to firefighters
        for i in range(number_of_firefighters):
            current_firefighter = self._crew[i]
            skill_level = adjust_skills[i]
            if skill_level > 3:             #if the adjusted skill level is above 3 or below 1, adjust to these boundaries 
                skill_level = 3
            elif skill_level < 1:
                skill_level = 1
            current_firefighter.set_level(skill_level)
            
            #TODO test what happens if ave skill is higher than max level,  

        
        
    def firefigher_round(self) -> None:
        """
        
        If there is more than one firefighter at a fire, both help extinguish the fire
        
        If the first firefighters extinguish, then the others others move, this is done after treepatch evolution
        
        Precondition:
        Only nodes from the graph are in play, no location is outside the graph
        """
        #determine is any fires have 2 or more firefighters 
        
        node_to_firefighter = {}                                #Dict to hold node and the number of firefighters at that node
        
        for firefighter in self._crew:
            location = firefighter._location 
            
            if location not in node_to_firefighter:             #No other firefighters at this node, so far
                node_to_firefighter[location] = [firefighter]
            else:                                               #At least one other firefighter at this node
                node_to_firefighter[location].append(firefighter)
                
        #seperate actions based on number of firefighters
        for node, list_firefighter in node_to_firefighter.items():   #cycle through all nodes with a firefighter
            nodepatch = self._graph.get_node_patch(node)
            if len(list_firefighter) == 1:                       #only one firefighter present
                current_firefighter = list_firefighter[0]
                current_firefighter.move_to_next()               #act as normal
            elif len(list_firefighter) >= 2:                     #more than one firefighter present
                #No fire
                if isinstance(nodepatch, Treepatch) and nodepatch.getter_ablaze() == False or isinstance(nodepatch, Rockpatch):
                    for fighter in list_firefighter:
                        fighter.move_to_next()
                else:                                           #patch on fire
                    tot_extinguish_stat = 0                     #total fire extinguishing stat for all firefighters present
                    for fighter in list_firefighter:
                        if tot_extinguish_stat >= 3:            
                            nodepatch.setter_ablaze(False)      #if the total fire extinguish stat is more than the fire level, default 3, then the fire should be put out
                            fighter.move_to_next()
                        else:                                   #fire not yet out
                            fighter.fire_extinguish()
                            tot_extinguish_stat += fighter._fire_extinguish_stat
            else:                                               #no firefighters present at all, should not happen as they should not be included in the nodes_for_firefighter dict
                continue                                        #move to next node 

        
        
    
