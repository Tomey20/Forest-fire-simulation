from typing import List, Tuple, Set, Dict, Any


class Graph:
    def __init__(self, edges:list[tuple[int, int]]): 
        """
        Generates an instance of a graph based on all the edges of the graph.
        
        Arg:
        edges: a list of tuples containing all edges of the graph. As a precondition
        these must be of length 2, must be unique, contain only positive ints, 
        and not represent loops.
        
        Attributes:
        edges: the list of tuples that is the edges
        neighbours: a dict where every node is a key and the element is all nodes
        to which the key node has a direct connection.
        nodes_instance: a dict that contain the ID of a node, used to assign Treepatch 
        or Rockpatch (or any other required class)
        
        """
        #consider if neighbours should be here or somewhere else
            
        self._edges = edges 
        if len(self._edges) == 0:
            raise ValueError ("An empty graph was passed")
        
        #Set self.neighbours
        neighbours = {}   #dict to hold results
            
        for edge in self._edges:                            #iterate over each edge in the list of tuples
            for node in edge:                               #iterates over each vertex/node in the tuple
                neighbour = {n for n in edge if n != node}  #adds all elements from edge ≠ current node, to a set (set to avoid unhashable error) 
                if node not in neighbours:                  #node not already in dict
                    neighbours[node] = set(neighbour)       #adds the neigbour list to the set assigned key(node) in the dictionary
                else:                                       #node already in dict
                    neighbours[node].update(neighbour)
            
        self._neighbours = neighbours

        self._nodes_instance = {node: None for node in self._neighbours.keys()}
    
        
#Getters
    def get_edges(self) -> list[tuple[int, int]]:
        return self._edges

    def get_nodes(self) -> set:
        """
        Returns a set of nodes found by iterating through the keys of self.neighbours.
        """
        nodes = self._neighbours.keys()
        return set(nodes)
    
    def get_neighbours(self) -> dict[int:set[int]]:
        return self._neighbours
    
    def get_nodes_instance(self) -> set[int]:
        return self._nodes_instance
    
    def get_node_patch(self, node): #patch and not ID to clearly see the difference between the two functions
        """
        Returns the assigned class of a single given node.
        """
        return self._nodes_instance[node]
    
#Setters
    #There is no setter for edges, because setting "edges" would mean overriding the object and making a new graph
        
    def set_node_patch(self, node:int, patch = None) -> None:
        """
        Sets the ID for a single given node.
        """
        if node not in self.get_nodes():
            raise ValueError ("Chosen node is not in the graph")
            
        self._nodes_instance[node] = patch


        
        
        


