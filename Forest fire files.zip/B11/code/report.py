import simulation
import matplotlib.pyplot as mplpp

class Report:
    def __init__(self) -> None:
        self.count = {}

    def setter_count(self, iteration_step:int, list_count:list):
        self.count[iteration_step] = list_count

    def report(self):
        """
        Generates a labelled graph, showing the plots of the three update functions,
        where update round is the x-coordiante and global frustation the y - coordinate.
        
        Arg:
        update_data: a dictionary of the data passed from update functions
        
        Return: 
        A plot of the data
        
        Packages:
        - Matplotlib 
        """
        
        #generate x_coordinates
        x_coordinates = list(self.count.keys())       #Makes alist of all keys
        
        y_treepatches = []                                         #List of values for ordered update
        y_rockpatches = []                                         #List of values for maxViolation update
        y_fire = []                                                #List of values for MonteCarlo update

        for value in self.count.values():      #for each list in the dictionary
            y_treepatches.append(value[0])
            y_rockpatches.append(value[1])
            y_fire.append(value[2])
        
        #adding data to plot
        mplpp.plot(x_coordinates, y_treepatches, marker = ",", linestyle = "-", 
                color = "g", label = "Tree patches")
        
        mplpp.plot(x_coordinates, y_rockpatches, marker = ",", linestyle = "-", 
                color = "b", label = "Rock patches")
        
        mplpp.plot(x_coordinates, y_fire, marker = ",", linestyle = "-", 
                color = "r", label = "Fire")
        
        # Displays only the given x-coordiantes, not halfs
        mplpp.xticks(x_coordinates)
        
        #adding legends
        mplpp.xlabel("Update Round")
        mplpp.ylabel("Number of patches")
        mplpp.title("Evolution of landpatches over time")
        mplpp.legend()
        
        
        #show the plot
        mplpp.show()

 
