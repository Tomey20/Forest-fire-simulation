import random
from class_landscape import Landpatch, Treepatch, Rockpatch
from fireFighter import Firefighter, FireCrew
from generation import Graph

class Simulation:
    """
    An instance of this class is used for the initialization of the parameters used in the simulation and for updating said parameters
    """
    def __init__(self, graph, tree_pop:int, FirefighterCrew, skill_level:int, AutoCombustion:float, Transmission:float, Respawn:float) -> None:
        self.graph = graph
        self.tree_pop = tree_pop
        self.FirefighterCrew = FirefighterCrew
        self.skill_level = skill_level
        self.AutoCombustion = AutoCombustion
        self.Transmission = Transmission
        self.Respawn = Respawn
        self.tree_map = None
        self.rock_map = None

    def get_tree_map(self) -> dict:
        """
        Returns the colour dictionary for tree nodes
        """
        return self.tree_map

    def get_rock_map(self) -> dict:
        """
        Returns a list of all rock nodes
        """
        return self.rock_map

    def assign(self) -> dict:
        """
        Assign the landpatch subclasses as a element in the dict
        """
        for nodes in self.graph.get_nodes():
            if self.tree_pop == 1:
                self.graph.set_node_patch(nodes, Treepatch(self.graph, nodes, self.Respawn, self.AutoCombustion, self.Transmission)) #change 0.3 0.3 to user chosen variables

            elif self.tree_pop == 2:
                self.graph.set_node_patch(nodes, Rockpatch(self.graph, nodes, self.Respawn, self.AutoCombustion, self.Transmission))

            elif self.tree_pop == 3:
                if random.random() <= 0.5:
                    self.graph.set_node_patch(nodes, Treepatch(self.graph, nodes, self.Respawn, self.AutoCombustion, self.Transmission))
                else:
                    self.graph.set_node_patch(nodes, Rockpatch(self.graph, nodes, self.Respawn, self.AutoCombustion, self.Transmission))
            else:
                raise AttributeError ("something went wrong")

    def define_colour(self) -> None:
        """
        makes a dictionaty containing the colors of tree nodes and a list of rock instances
        """
        tree_maps = {}
        rock_maps = {}
        for node in self.graph.get_nodes():
            node_patch = self.graph.get_node_patch(node) 
            if isinstance(node_patch, Treepatch):
                if node_patch.getter_ablaze() == False:
                    tree_maps[node] = node_patch.getter_stat()
                elif node_patch.getter_ablaze() == True:
                    tree_maps[node] = -256+(node_patch.getter_stat())
            else:
                rock_maps[node] = self.graph.get_node_patch(node)
        self.tree_map = tree_maps
        self.rock_map = rock_maps

    def update_firefighters(self) -> None:
        """
        Updates all firefighters in a given round. It consideres their action
        and then updates the resulting locations into self.location.
        """
        self.FirefighterCrew.firefigher_round() #All firefighters take an action
        self.FirefighterCrew.update_locations()
                
    def count_patches(self) -> None:
        """
        This function counts and returns the total number of treepatches, treepatches on fire and rockpatches over time.
        """
        tree_count = len(self.tree_map)
        fire_count = 0
        for key in self.tree_map:
            if self.tree_map[key] < 0:
                fire_count += 1

        rock_count = len(self.rock_map)
        count = [tree_count, rock_count, fire_count]
        return count               
        
    def land_evolution(self) -> None:
        """
        This function updates the landpatches, by calling on the functions responsible for transmitting fire, mutate trees, mutate rocks, ects. 
        """
        for nodes in self.graph.get_nodes_instance(): #gets the instance of tree of land
            nodepatch = self.graph.get_node_patch(nodes)
            if isinstance(nodepatch, Treepatch):
                nodepatch.auto_ignition()
                nodepatch.wildfire_transmission()
                nodepatch.update_land()
                nodepatch.tree_mutation()
                
                if nodepatch.getter_mark() == True:         #change all marked trees to ablaze == True and marked == False
                    nodepatch.setter_ablaze(True)
                    nodepatch.setter_marker(False)
                    
            elif isinstance(nodepatch, Rockpatch):                         #instance is a rockpatch
                nodepatch.rock_mutation()
            else:
                print("Error in land_evolution")
            
       
    def initialize(self) -> None:
        """
        This function calls on the respective functions, which are needed to initialize and set the beginning parameters for the simulation
        """
        self.assign()
        self.define_colour()
        if len(self.FirefighterCrew.get_crew()) >= 1:
            self.FirefighterCrew.set_ave_skill(self.skill_level)

    def Simulation_updates(self) -> None:
        """
        This function calls on the respective functions, which are used to update the parameters responsible for setting the landscape and firefighter position
        """
        self.land_evolution()
        if len(self.FirefighterCrew.get_crew()) >= 1:   
            self.update_firefighters()
        self.define_colour()
        
        
