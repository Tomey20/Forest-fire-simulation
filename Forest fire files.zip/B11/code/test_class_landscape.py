import unittest
from unittest.mock import patch, Mock
from generation import Graph
from simulation import Simulation
from fireFighter import FireCrew
from class_landscape import Treepatch, Rockpatch


class test_class_landscape(unittest.TestCase):
    
    @classmethod
    def setUpClass(self):
        """setting the instance up for unittesting"""
        #graph instance
        self.g = Graph([(1,2),(1,3),(2,3)])
        self.g.set_node_patch(1,Treepatch(self.g, 1, 1.0, 1.0, 1.0))
        self.g.set_node_patch(2,Rockpatch(self.g, 2, 1.0, 1.0, 1.0))
        self.g.set_node_patch(3,Treepatch(self.g, 3, 1.0, 1.0, 1.0))

        #making patch instance
        self.tree = self.g.get_node_patch(1)
        self.rock = self.g.get_node_patch(2)
        self.tree_next = self.g.get_node_patch(3)

    @classmethod
    def tearDownClass(self):
        """Cleaning up resources after all tests in the class have run"""
        # Perform cleanup steps for the entire test class
        del self.g
        del self.tree
        del self.rock
        del self.tree_next
    
    def test_getters(self):
        self.assertEqual(self.tree.getter_neighbor(), {2, 3})
        self.assertIsInstance(self.tree.getter_neighbor(), set)

    def test_auto_ignition(self):
        self.tree.auto_ignition()

        self.assertTrue(self.tree.getter_mark())
        self.assertIsInstance(self.g.get_node_patch(1), Treepatch)
        self.assertIsInstance(self.tree, Treepatch)
        self.assertIsInstance(self.tree.getter_mark(), bool)

    def test_updateland(self):
        self.tree.treestat = 250
        self.tree_next.treestat =250
        self.tree.ablaze = True

        self.tree.update_land()
        self.tree_next.update_land()
        self.assertIsInstance(self.tree.getter_stat(), int)
        self.assertEqual(self.tree.getter_stat(), 230)

        self.assertIsInstance(self.tree_next.getter_stat(), int)
        self.assertEqual(self.tree_next.getter_stat(), 256)


    def test_tree_mutation(self):
        self.tree.setter_stat(-256)
        self.tree.tree_mutation()
        
        self.assertIsInstance(self.g.get_node_patch(1), Rockpatch)

    def test_rock_mutation(self):
        self.rock.rock_mutation()
        self.assertIsInstance(self.g.get_node_patch(2), Treepatch)

    def test_wildfire_transmission(self):
        self.tree.setter_ablaze(True)
        
        self.tree.wildfire_transmission()

        self.assertEqual(self.tree.getter_neighbor(), {2, 3})
        self.assertIsInstance(self.g.get_node_patch(3), Treepatch)
        self.assertTrue(self.tree.getter_ablaze())                  #node 1 ablaze == True
        self.assertEqual(self.tree_next.getter_mark(), True)               #node 3 mark == True'
        self.assertIsInstance(self.tree_next.getter_mark(), bool)   #the mark is a bool type

if __name__ == "__main__":
    unittest.main()