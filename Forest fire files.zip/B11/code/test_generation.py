#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 30 16:36:13 2023

@author: Sofie
"""

import unittest
from generation import Graph
from class_landscape import Treepatch, Rockpatch

class TestGraph(unittest.TestCase):
    def setUp(self):
        #set up graph instance to test on
       self.graph1 = Graph([(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)])
       with self.assertRaises(ValueError):
           Graph([])

    
    def test_get_nodes(self):
        self.assertEqual(self.graph1.get_nodes(), {0, 1, 2, 3, 4})
        
        
    
    def test_get__edges(self):
        self.assertEqual(self.graph1.get_edges(), [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)])

    def test_get_neighbours(self):
        self.assertEqual(self.graph1.get_neighbours(), {0: {1, 4}, 1: {0, 2}, 2: {1, 3}, 3: {2, 4}, 4: {0, 3}})
    
    def test_get_node_patch(self):
        node = 1
        self.assertEqual(self.graph1.get_node_patch(node), None)
        
    def test_get_nodes_ID(self):
        self.assertEqual(self.graph1.get_nodes_instance(), {0: None, 1: None, 
                                                            2: None, 3: None, 
                                                            4: None})
        
    def test_set_node_patch(self):
        self.graph1.set_node_patch(0, Treepatch)    #valid
            
        with self.assertRaises(ValueError):
            self.graph1.set_node_patch(5, Treepatch)

if __name__ == "__main__":
    unittest.main()
    


   


    
    
    