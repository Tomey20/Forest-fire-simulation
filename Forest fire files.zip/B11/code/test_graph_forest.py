import unittest
from unittest.mock import patch
from user_interface import UserInterface, UserQuitException
import visualiser_random_forest_graph as vr
import graph_helper
import random
from generation import Graph
from simulation import Simulation
from class_landscape import Landpatch, Treepatch, Rockpatch
from fireFighter import Firefighter, FireCrew
from report import Report
from graph_forest import graph_forest

class TestMainModule(unittest.TestCase):
    @patch('graph_forest.UserInterface')
    @patch('graph_forest.Graph')
    @patch('graph_forest.FireCrew')
    @patch('graph_forest.Simulation')
    @patch('graph_forest.vr.Visualiser')
    @patch('graph_forest.Report')
    @patch('os.path.exists', return_value=True)
    @patch('os.path.getsize', return_value=42)
    @patch('builtins.open', create=True, new_callable=unittest.mock.mock_open, read_data='#this line should be ignored\n0,1\n1,2\n2,3\n3,0')
    @patch('user_interface.graph_helper.edges_planar', return_value=True)
    @patch('builtins.input', side_effect=['file', 'valid\\file_path\\file.dat', 'all_wood', '2', '2', '0.2', '0.1', '0.1', '10'])
    def test_a_valid_run(self, mock_ui, mock_graph, mock_fire_crew, mock_simulation, mock_visualiser, mock_report, mock_exists, mock_getsize, mock_open, mock_edges_planar, mock_input):
        ui = mock_ui.return_value  # Obtain the instance from the mock object
        graph_method = "file"
        ui.file_content = [[0, 1], [1, 2], [2, 3], [3, 0]]
        ui.List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        graph_forest()
        self.assertEqual(ui.graph, "file")
        self.assertEqual(ui.tree_pop, 1)
        self.assertEqual(ui.firefighters, 2)
        self.assertEqual(ui.skill_level, 2)
        self.assertEqual(ui.Ignition, 0.2)
        self.assertEqual(ui.Transmission, 0.1)
        self.assertEqual(ui.Respawn, 0.1)
        self.assertEqual(ui.Itteration_steps, 10)
        result = ui.get_parameters()
        expected_result = (1, 2, 2, 0.2, 0.1, 0.1, 10)
        self.assertEqual(result, expected_result)
        
if __name__ == '__main__':
    unittest.main()

