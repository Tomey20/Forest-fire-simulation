import random
from class_landscape import Landpatch, Treepatch, Rockpatch
from fireFighter import Firefighter, FireCrew
from generation import Graph
import unittest
from unittest.mock import patch
from simulation import Simulation
class TestSimulation(unittest.TestCase):
    def test_assign_all_tree(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 1
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        self.sim.assign()
        for node in self.graph.get_nodes():
            node_patch = self.graph.get_node_patch(node) 
            self.assertIsInstance(node_patch, Treepatch)

    def test_assign_all_rocks(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 2
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        self.sim.assign()
        for node in self.graph.get_nodes():
            node_patch = self.graph.get_node_patch(node) 
            self.assertIsInstance(node_patch, Rockpatch)

    def test_assign_random(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 3
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        self.sim.assign()
        for node in self.graph.get_nodes():
            node_patch = self.graph.get_node_patch(node) 
            self.assertIsInstance(node_patch, (Rockpatch, Treepatch))

    def test_define_colour_all_tree(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 1
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        self.sim.assign()
        self.sim.define_colour()
        self.assertTrue(len(self.sim.tree_map) == 4)
        self.assertTrue(len(self.sim.rock_map) == 0)
        for key, value in self.sim.tree_map.items():
            self.assertTrue(value >= 0)

    def test_define_colour_all_rock(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 2
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        self.sim.assign()
        self.sim.define_colour()
        self.assertTrue(len(self.sim.tree_map) == 0)
        self.assertTrue(len(self.sim.rock_map) == 4)
        for key, value in self.sim.rock_map.items():
            self.assertIsInstance(value, Rockpatch)

    def test_define_colour_random(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 3
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        # We don't run self.sim.assign() because we want to controle the patch assignment
        self.graph.set_node_patch(0, Treepatch(self.graph, 0, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(1, Treepatch(self.graph, 1, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(2, Rockpatch(self.graph, 2, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(3, Rockpatch(self.graph, 3, Respawn, AutoCombustion, Transmission))
        self.sim.define_colour()
        self.assertTrue(len(self.sim.tree_map) == 2)
        self.assertTrue(len(self.sim.rock_map) == 2)
        self.assertTrue(self.sim.tree_map[0] >= 0)
        self.assertTrue(self.sim.tree_map[1] >= 0)
        self.assertIsInstance(self.sim.rock_map[2], Rockpatch)
        self.assertIsInstance(self.sim.rock_map[3], Rockpatch)

    def test_define_colour_random_with_fire(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 3
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        # We don't run self.sim.assign() because we want to controle the patch assignment
        self.graph.set_node_patch(0, Treepatch(self.graph, 0, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(1, Treepatch(self.graph, 1, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(2, Rockpatch(self.graph, 2, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(3, Rockpatch(self.graph, 3, Respawn, AutoCombustion, Transmission))
        node_patch = self.graph.get_node_patch(0)
        node_patch.setter_ablaze(True)
        self.sim.define_colour()
        self.assertTrue(len(self.sim.tree_map) == 2)
        self.assertTrue(len(self.sim.rock_map) == 2)
        self.assertTrue(self.sim.tree_map[0] < 0)
        self.assertTrue(self.sim.tree_map[1] >= 0)
        self.assertIsInstance(self.sim.rock_map[2], Rockpatch)
        self.assertIsInstance(self.sim.rock_map[3], Rockpatch)

    def test_count_patches_zero_fire(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 3
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        # We don't run self.sim.assign() because we want to controle the patch assignment
        self.graph.set_node_patch(0, Treepatch(self.graph, 0, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(1, Treepatch(self.graph, 1, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(2, Rockpatch(self.graph, 2, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(3, Rockpatch(self.graph, 3, Respawn, AutoCombustion, Transmission))
        self.sim.define_colour()
        result = self.sim.count_patches()
        expected_result = [2, 2, 0]
        self.assertEqual(result, expected_result)

    def test_count_patches_with_fire(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 3
        FirefighterCrew = 2
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        # We don't run self.sim.assign() because we want to controle the patch assignment
        self.graph.set_node_patch(0, Treepatch(self.graph, 0, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(1, Treepatch(self.graph, 1, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(2, Rockpatch(self.graph, 2, Respawn, AutoCombustion, Transmission))
        self.graph.set_node_patch(3, Rockpatch(self.graph, 3, Respawn, AutoCombustion, Transmission))
        self.sim.define_colour()
        self.sim.tree_map[0] = -100
        result = self.sim.count_patches()
        expected_result = [2, 2, 1]
        self.assertEqual(result, expected_result)
        
    # if the value is less than or equal to the probability, it will always trigger in the mock.  eg AutoCombustion = 0.2, so if it is 0.1 it WILL trigger.   
    def test_land_evolution(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 3
        FirefighterCrew = 2 
        skill_level = 1
        AutoCombustion = 0
        Transmission = 0
        Respawn = 0
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        # We don't run self.sim.assign() because we want to controle the patch assignment
        self.graph.set_node_patch(0, Treepatch(self.graph, 0, 0, 0, 0)) # node, Respawn, AutoCombustion, Transmission
        self.graph.set_node_patch(1, Treepatch(self.graph, 1, 0, 0, 0))
        self.graph.set_node_patch(2, Rockpatch(self.graph, 2, 1, 0, 0))
        self.graph.set_node_patch(3, Rockpatch(self.graph, 3, 0, 0, 0))
        nodepatch0 = self.graph.get_node_patch(0)
        nodepatch0.treestat = 10
        nodepatch0.setter_ablaze(True)
        self.sim.land_evolution()
        self.assertIsInstance(self.graph.get_node_patch(0), Rockpatch)
        self.assertIsInstance(self.graph.get_node_patch(1), Treepatch)
        self.assertIsInstance(self.graph.get_node_patch(2), Treepatch)
        self.assertIsInstance(self.graph.get_node_patch(3), Rockpatch)

    def test_get_tree_map(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 3
        FirefighterCrew = 2 
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        self.sim.assign()
        self.sim.define_colour()
        result = self.sim.get_tree_map()
        self.assertIsInstance(result, dict)

    def test_get_rock_map(self):
        List_of_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        self.graph = Graph(List_of_tuples)
        tree_pop = 3
        FirefighterCrew = 2 
        skill_level = 1
        AutoCombustion = 0.2
        Transmission = 0.1
        Respawn = 0.1
        self.sim = Simulation(self.graph, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
        self.sim.assign()
        self.sim.define_colour()
        result = self.sim.get_rock_map()
        self.assertIsInstance(result, dict)

if __name__ == '__main__':
    unittest.main()
