import os
import copy
import graph_helper

class UserQuitException(Exception):
    pass
    
class UserInterface:
    """
    An instance of this class, will allow parameters to be set by the user and retrieved, when the class methods are run for that instance.
    """
    def __init__(self, graph:str = None, file_content:list = [], minimum_points:int = None, tree_pop:int = None, list_of_tuples:list[tuple] = None, Itteration_steps:int = None,
                 skill_level:int = None, Ignition:float = None, Transmission:float = None, Respawn:float = None):
        print("This is a simulation of a forest fire on a graph\nPress q at any point during the configuration to exit the program")
        self.graph = graph
        self.file_content = file_content
        self.minimum_points = minimum_points
        self.tree_pop = tree_pop
        self.list_of_tuples = list_of_tuples
        self.Itteration_steps = Itteration_steps
        self.skill_level = skill_level
        self.Ignition = Ignition
        self.Transmission = Transmission
        self.Respawn = Respawn
    """
    Parameters
    ----------
    graph: str, default = None
      String defining if the user wants to generating a graph from a file or a random graph. String can be either random_generation or file.
    file_content: list, default = []
      An empty list which is used to store the content of the provided file, which will be added to the list line by line.
    minimum_points: int, default = None
      The minimum number of points for the random generation
    tree_pop: int, default = None
      An integer defining whether all of the nodes should be: 1 for all_wood, 2 for all_rocks or 3 for random
    list_of_tuples: list[tuple], default = None
      A list of tuples which is a list of the edges (Tuples of 2 vertices) forming the 2D surface for the simulation
    Itteration_steps: int, default = None
        An integer number of itteration steps the simulation will run
    skill_level: int, default = None
        An integer number of the average skill of the firefighters. 1 is bad, 2 is good, 3 is great.
    Ignition: float, default = None
        A float which describes the probability of a tree self-igniting.
    Transmission: float, default = None
        A float which describes the probability of a tree spreading the fire to a neighbouring tree.
    Respawn: float, default = None
        A float which defines the probability of a tree growing or respawning from a rock patch
    """
    
    def set_graph_method(self)-> None:
        """
        Allows the user to choose which methed they want to choose for generating a graph. The input can either be "random_generation", "file" or "q" to quit the program .
        """
        while True:
            print("Please choose your prefered method of generating a graph\nPick either random_generation or file")
            graph_choice = input().lower().replace(" ", "")
            if graph_choice == "random_generation":
                self.graph = "random_generation"
                break
                        
            if graph_choice == "q":
                raise UserQuitException()

            
            if graph_choice == "file":
                self.graph = "file"
                break
                
            else:
                print("Invalid choice.")
        

        
    def get_graph_method(self)-> str:
        """
        Returns the choice of the graph method to the main module 
        """
        return self.graph

    def load_graph_from_file(self):
        """
        Allows the user to upload the path to their file. The file will be checked for various error, such as file not found, incomplete lines, text in the lines, an empty file, if the graph is connected, ects.
        Press q to quit.
        """
        while True:
            print("Please provide the file path, to your .dat file")
            file_path = input()
            # Checks if the file path exists and if the file is not empty and if the file is a .dat file. If it is, it will proceed to read the file
            # If the file is located in the same map as the user interface and you just insert the dat file, os.path.exists(file_path) is automatically true
            if os.path.exists(file_path) and os.path.getsize(file_path) > 0 and file_path.endswith(".dat"):    
                # Open the file in default text reader mode
                with open(file_path, 'r') as file:
                    # Read the contents of the file
                    for line in file:
                        # Ignore lines starting with '#' (comment lines)
                        if line.startswith('#') or len(line.strip()) == 0:
                            continue
                        # Split the lines to individual elements ("1, 2" -> ['1', '2']) and remove leading and trailing whitespace
                        split_elements = [element.strip() for element in line.split(',')] # list comprehension

                        # Check if the line/list (split_elements) is of length 2 and if each element is a numeric/digit. It also checks if all elements is above 0, to avoid negative 
                        if len(split_elements) == 2 and all(element.isdigit() for element in split_elements)and all(int(element) >= 0 for element in split_elements):
                            # Append the elements as a list to file_content
                            self.file_content.append([int(element) for element in split_elements])
     
                    # We check if all the lines were faluty, and thus the content is empty
                    if len(self.file_content) == 0:
                        print("None of the lines in the file were valid, Please upload a file with valid information")
                        raise UserQuitException()
        
                    # Here we check if the graph is connected: we do Depth-First Search (DFS) 
                    adjacency_list = {}
                    for edge in self.file_content:
                        adjacency_list.setdefault(edge[0], []).append(edge[1])
                        adjacency_list.setdefault(edge[1], []).append(edge[0])

                    start_node = next(iter(adjacency_list.keys()))
                    stack = [start_node]
                    visited = set()

                    while stack:
                        node = stack.pop()
                        visited.add(node)

                        for neighbor in adjacency_list[node]:
                            if neighbor not in visited:
                                stack.append(neighbor)
                    # Check if all nodes are visited
                    if len(visited) == len(adjacency_list):
                        
                        # sort the elements of the list and removes edges that loops to themselves and repeated edges
                        for edge in self.file_content:
                            edge.sort()  # sorts the nested lists

                        sorted_edges = sorted(self.file_content)  # makes a new list that is edges sorted

                        edge_list = []  # placeholder to hold unique edges
                        repeated = []

                        for edge in sorted_edges:
                            if edge[0] == edge[1] or edge in edge_list:  # removes loops and repeated edges
                                repeated.append(edge)
                            else:
                                edge_list.append(edge)

                                
                        if len(edge_list) != len(self.file_content):
                            print("There was at least one faulty line in the passed file, they have been ignored.")
                            
                        # Make a list of tuples
                        l_o_t = [tuple(inner_list) for inner_list in edge_list]
                        if graph_helper.edges_planar(l_o_t) == True:
                            # The max(self.list_of_tuples, key=lambda x: x[1]) gives us the tuple eg. (1, 3) with the maximum value in it. then we do put[1] at the end to get 3
                            # The key=lambda x: x[1] specifies that the maximum should be determined based on the second element of each tuple.
                            if max(l_o_t, key=lambda x: x[1])[1] <= len(l_o_t): # We check if the maximum element exceeds the total unmber of nodes. 
                                self.list_of_tuples = l_o_t
                                return self.list_of_tuples
                            
                            else:
                                print("The maximum element in the file, exceeds the length of the total number of nodes, which will result in an error in the visualisation\nPlease provide a valid file")
                                raise UserQuitException()
                        
                        else:
                            print("list of tuples are not planar. Please provide a file with planar edges")
                            raise UserQuitException()

                    else:
                        print("The file you provided is not connected. Please make sure that all of the nodes are connected next time")
                        raise UserQuitException()            
            
            elif file_path == "q":
                raise UserQuitException()
            
            else:
                print("Invalid input or something was wrong with the file.\nPlease ensure that the correct file path was given, that the file is not of size 0 and that the provided file is a .dat file.")


    def set_minpoints(self) -> int:
        """
        Alllows the user to pick an whole integer number from 4 and above, which is used for the helper function voronoi_to_edges(), which requires a minimum number of points, to generate the graph.
        Press q to quit the program.
        """
        while True:
            print("Please pick an integer whole number of 4 or above for the number of desired nodes")
            minimum_points = input()

            if minimum_points.isdigit() and int(minimum_points) >= 4:
                self.minimum_points = int(minimum_points)
                break

            if minimum_points == "q":
                raise UserQuitException()

            else:
                print("An invalid minimum number of nodes")
                
    def get_minpoints(self) -> int:
        """
        Returns the minimum number of points as an integer, used for the voronoi_to_edges() function.
        """
        return self.minimum_points

    def set_parameters(self, number_of_nodes:int) -> None:
        """
        This function runs all of the set parameters function, which interacts with the user.
        ----------
        Parameters
        ----------
        number_of_nodes: int
        An integer indicating the total number of nodes in the graph, to inform the user about the total number of firefighters you can choose
        """
        self.set_landscape()
        self.set_firefighters(number_of_nodes)
        self.set_skill()
        self.set_ignition()
        self.set_transmission()
        self.set_forest_respawn()
        self.set_itterations()
        
        
    def set_landscape(self) -> None:
        """
        This function allows the user to choose the initial landscape of the simulation. It can either be all_wood, all_rocks or random. Press q to quit the program

        """
        # choose the landscape
        while True:
            print("Select your initial landscape\nChoose either all_wood, all_rocks or random")
            landscape_choice = input().lower().replace(" ", "")

            if landscape_choice == "all_wood":
                self.tree_pop = 1
                break

            if landscape_choice == "all_rocks":
                self.tree_pop = 2
                break

            if landscape_choice == "random":
                self.tree_pop = 3
                break
            

            if landscape_choice == "q":
                raise UserQuitException()
            
            else:
                print("Invalid input")
        
        
    def set_firefighters(self, number_of_nodes) -> None:
        """
        This function allows the user to choose the number of firefighters for the simulation. It can be a minimum of 0 firefighters and any integer above.
        Press q to quit the program.
        ----------
        Parameters
        ----------
        number_of_nodes: int
        An integer indicating the total number of nodes in the graph, to inform the user about the total number of firefighters you can choose

        """
        # Choose the number of firefighters
        while True:
            print("please pick your number of firefighters. It can minimum be 0 and maximum be:", number_of_nodes)
            Number_of_firefighters = input()
            
            if Number_of_firefighters.isdigit() and int(Number_of_firefighters) >= 0 and int(Number_of_firefighters)<= number_of_nodes:
                self.firefighters = int(Number_of_firefighters)
                break

            if Number_of_firefighters == "q":
                raise UserQuitException()
            
            else:
                print("Invalid input")

    def set_skill(self) -> None:
        """
        This function allows the user to choose the average skill level of the firefighters for the simulation. It can be either 1, 2 or 3.
        Press q to quit the program.

        """
        # skill level of firefighters
        while True:
            print("Choose the firefighters average skill level. Pick either 1, 2 or 3")
            skill = input()

            if skill.isdigit() and 0 < int(skill) < 4:
                self.skill_level = int(skill)
                break

            if skill == "q":
                raise UserQuitException()

            else:
                print("Invalid input")
                
    def set_itterations(self) -> None:
        """
        This function allows the user to choose the average skill level of the firefighters for the simulation. It can be either 1, 2 or 3.
        Press q to quit the program.

        """
        # Number of itterations
        while True:
            print("Please select the number of itteration steps (whole integer above 0) in your simulation.")
            Itterations = input()

            if Itterations.isdigit() and int(Itterations) >= 1:
                self.Itteration_steps = int(Itterations)
                break

            if Itterations == "q":
                raise UserQuitException()
            
            else:
                print("Invalid input")

    # Set probabilities for ignition, transmission, and forest respawn
    def set_ignition(self):
        """
        This function allows the user to choose the probability of a tree patch self-igniting in the simulation. It can be a float from 0 to- and including 1.
        Press q to quit the program.

        """
        while True:
            print("Please pick the probability of fire ignition. It can be a float from 0 to 1")
            Ignition = input()
            if Ignition == "q":
                raise UserQuitException()

            try:
                float_ignition = float(Ignition.replace(',', '.'))
                if 0 <= float_ignition <= 1:
                    self.Ignition = float_ignition
                    break

                else:
                    print("Invalid input")
                            
            except ValueError:
                print("Invalid input. Please enter a numeric value.")

    def set_transmission(self) -> None:
        """
        This function allows the user to choose the probability of a tree transmitting the fire to a neighbouring tree patch in the simulation. It can be a float from 0 to- and including 1.
        Press q to quit the program.

        """
        while True:
            print("Please pick the probability of transmitting the fire to neighboring trees. It can be a float from 0 to 1")
            Transmission = input()
            if Transmission == "q":
                raise UserQuitException()

            try:
                float_transmission = float(Transmission.replace(',', '.'))
                if 0 <= float_transmission <= 1:
                    self.Transmission = float_transmission
                    break

                else:
                    print("Invalid input")
                            
            except ValueError:
                print("Invalid input. Please enter a numeric value.")

    def set_forest_respawn(self) -> None:
        """
        This function allows the user to choose the probability of a tree respawning from a rockpatch in the simulation. It can be a float from 0 to- and including 1.
        Press q to quit the program.

        """
        while True:
            print("Please pick the probability of respawning a forest. It can be a float from 0 to 1")
            Respawn = input()
            if Respawn == "q":
                raise UserQuitException()

            try:
                float_respawn = float(Respawn.replace(',', '.'))
                if 0 <= float_respawn <= 1:
                    self.Respawn = float_respawn
                    break

                else:
                    print("Invalid input")
                            
            except ValueError:
                print("Invalid input. Please enter a numeric value.")
                
    def get_parameters(self) -> tuple[int, int, str, int, float, float, float]:
        """
        This function returns all of the parameters set by the user

        """
        return self.tree_pop, self.firefighters, self.skill_level, self.Itteration_steps, self.Ignition, self.Transmission, self.Respawn

