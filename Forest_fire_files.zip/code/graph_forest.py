from user_interface import UserInterface, UserQuitException
import visualiser_random_forest_graph as vr
import graph_helper
import random
from generation import Graph
from simulation import Simulation
from class_landscape import Landpatch, Treepatch, Rockpatch
from fireFighter import Firefighter, FireCrew
from report import Report
def graph_forest():
    ui = UserInterface()   # assign user interface to variable ui, to call on it
    try:
        ui.set_graph_method()   # The user gets to choose the graph method, upload a file or generate a random graph
        graph_method = ui.get_graph_method()
        if graph_method == "file":
            List_of_tuples = ui.load_graph_from_file()
                        
        elif graph_method == "random_generation":
            ui.set_minpoints()
            number_of_nodes = ui.get_minpoints()
            List_of_tuples, _ = graph_helper.voronoi_to_edges(number_of_nodes) # The _ is commonly used as a throwaway variable

        g = Graph(List_of_tuples)
        number_of_nodes = len(g.get_nodes())    
        ui.set_parameters(number_of_nodes)
        
    except UserQuitException as ex:  # We use only UserQuitException to catch only the exception that is raised when the user quits the program. ex is the instance of the class UserQuitException
        print("Quitting program")
        return

    tree_pop, firefighters, skill_level, Itteration_steps, AutoCombustion, Transmission, Respawn = ui.get_parameters()
    # Initialisation
    FirefighterCrew = FireCrew(g, firefighters, skill_level)
    sim = Simulation(g, tree_pop, FirefighterCrew, skill_level, AutoCombustion, Transmission, Respawn)
    sim.initialize()
    rock_maps = sim.get_rock_map()
    cmap = sim.get_tree_map()
    
    mvr = vr.Visualiser(List_of_tuples, node_size=50)

    reporting = Report()

    # Simulation:
    for i in range(Itteration_steps):
        firefighter_list = FirefighterCrew.get_locations()
        mvr.update_node_colours(cmap)
        mvr.update_node_edges(firefighter_list)
        sim.Simulation_updates()
        cmap = sim.get_tree_map()
        rock_maps = sim.get_rock_map()
        count = sim.count_patches()
        reporting.setter_count(i, count)
       
    mvr.wait_close()
    reporting.report()

if __name__ == '__main__':
    graph_forest()


