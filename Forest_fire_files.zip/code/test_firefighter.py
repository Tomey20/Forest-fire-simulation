#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan  7 14:57:03 2024

@author: Sofie
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 27 15:46:34 2023

@author: Sofie
"""

import unittest
from fireFighter import Firefighter, FireCrew
from generation import Graph
from class_landscape import Treepatch, Rockpatch
from unittest.mock import patch

class TestFireFighter(unittest.TestCase):
    
    def setUp(self): #sets up instances of a given class to test methods on
       
    #make mock graph to test on, this will have access to graph attributes and methods
        self.mock_graph = Graph([(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)]) 
        for node in self.mock_graph.get_nodes_instance():
            #make treepatches, autocombust and transmission as 0, to avoid their influence
            self.mock_graph.set_node_patch(node, Treepatch(self.mock_graph, node, 0, 0))
            #test that the graph now contains treepatches
            self.assertIsInstance(self.mock_graph.get_node_patch(node), Treepatch)
            #ablaze, mark are both False as default
        
        #Make firefighter instances to test clas Firefighter
        self.fireman = Firefighter(self.mock_graph)

        #make a mock crew to test FireCrew functions on
        self.mock_crew = FireCrew(self.mock_graph, 5)  #crew of 5, level not specified 
        
    def tearDown(self):
        #reset parameters to the initial ones 
        self.mock_graph = Graph([(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)]) 
        for node in self.mock_graph.get_nodes_instance():
            self.mock_graph.set_node_patch(node, Treepatch(self.mock_graph, node, 0, 0))
            self.assertIsInstance(self.mock_graph.get_node_patch(node), Treepatch)

        self.fireman = Firefighter(self.mock_graph)

        self.mock_crew = FireCrew(self.mock_graph, 5) 
        
        
    def test_get_level(self):
        self.assertEqual(self.fireman.get_level(), 1) #checks if the level is 1
    
    def test_get_location(self):
        self.assertIn(self.fireman.get_location(), {0, 1, 2, 3, 4})
    
    def test_get_fire_extinguish_stat(self):
        self.assertEqual(self.fireman.get_fire_extinguish_stat(), 0)
  
    def test_set_level(self):
       self.fireman.set_level(2)
       self.assertEqual(self.fireman.get_level(), 2) #checks if the level is 1
           
    def test_set_location_valid(self):
       self.fireman.set_location(2)
        
       self.assertEqual(self.fireman.get_location(), 2)
       
       with self.assertRaises(ValueError):
           self.fireman.set_location(10)
    
    def test_set_fire_extinguish_stat(self):
        with self.assertRaises(ValueError):
            self.fireman.set_fire_extinguish_stat(-1)
            self.fireman.set_fire_extinguish_stat(4)
            
        self.fireman.set_fire_extinguish_stat(3)
        self.assertEqual(self.fireman.get_fire_extinguish_stat(), 3)

    def test_move_to_next(self):
        #set fireman start location
        self.fireman.set_location(3)
        self.assertEqual(self.fireman.get_location(), 3)
        self.assertEqual(self.fireman.get_fire_extinguish_stat(), 0)
        
        #test move randomly
        self.fireman.move_to_next()
        self.assertIn(self.fireman.get_location(), self.mock_graph._neighbours[3])
        self.assertNotEqual(self.fireman.get_location(), 3) #the fireman should have moved
        
    @patch('random.choice')
    def test_move_to_next_fire(self, mock_choice):
        #set a patch to ablaze
        self.mock_graph.get_node_patch(3).setter_ablaze(True)
        self.assertTrue(self.mock_graph.get_node_patch(3).getter_ablaze())
        self.fireman.set_location(2)
        self.assertEqual(self.fireman.get_location(), 2)
        
        #fireman is currently not on spot 3, but on a neighbour, 
        #calling move to next will make him move to node 3
        mock_choice.return_value = 3
        
        self.fireman.move_to_next()

        self.assertEqual(self.fireman.get_location(), 3)
        self.assertEqual(self.fireman.get_fire_extinguish_stat(), 0)
 
        
        #check states are as intended
        self.assertTrue(self.mock_graph.get_node_patch(3).getter_ablaze())
        self.assertEqual(self.fireman.get_location(), 3)
        
        #3 is on fire, fireman should stay and extinguish
        self.fireman.move_to_next()
        self.assertEqual(self.fireman.get_location(), 3)
        

    def test_fire_extinguish(self):
        
        #Set a treepatch ablaze and ensure fireman is standing on it
        self.mock_graph.get_node_patch(3).setter_ablaze(True)
        self.assertTrue(self.mock_graph.get_node_patch(3).getter_ablaze())
        
        self.fireman.set_location(3)

        # Calling the method under test, initially the fire will not be extinguished
        self.fireman.fire_extinguish()
        self.assertEqual(self.fireman.get_fire_extinguish_stat(), 1)
        self.assertTrue(self.mock_graph.get_node_patch(3).getter_ablaze())
        
        #setting the fireman level up, this should ensure a fire extinguished
        self.fireman.set_fire_extinguish_stat(2) #extinguish fire in one go
        
        #test last case, own location is ablaze
        self.fireman.fire_extinguish()
        
        self.assertEqual(self.fireman.get_fire_extinguish_stat(), 0) #last level added to new one and reset
        self.assertFalse(self.mock_graph.get_node_patch(3).getter_ablaze())

    
#fireFighter.FireCrew
    
    def test___init__(self):
        with self.assertRaises(ValueError): #test wrong set-Up of firecrew
            firecrew = FireCrew(self.mock_graph, -1)

        self.assertEqual(type(self.mock_crew), FireCrew)

    def test_get_crew(self):
        self.assertEqual(len(self.mock_crew.get_crew()), 5)
        
        for firefighter in self.mock_crew._crew:
            self.assertEqual(type(firefighter), Firefighter)
        
    def test_get_ave_skill(self):
        self.assertIn(self.mock_crew.get_ave_skill(), [1, 2, 3])

    def test_get_locations(self):
        for elem in self.mock_crew.get_locations():
            self.assertIn(elem, {0, 1, 2, 3, 4})
    
    def test_set_ave_skills(self):
        self.mock_crew.set_ave_skill(2)
        self.assertEqual(self.mock_crew.ave_skill, 2)
        
        with self.assertRaises(ValueError):
            self.mock_crew.set_ave_skill(-1)
            self.mock_crew.set_ave_skill(4)
            self.mock_crew.set_ave_skill(2.5)


    def test_set_skills(self):
        # Set a specific average skill level
        self.mock_crew.set_ave_skill(2)

        # Retrieve skills of firefighters
        skills = [firefighter.get_level() for firefighter in self.mock_crew.get_crew()]

        # Test if all skills are within the allowed range
        for skill in skills:
            self.assertTrue(1 <= skill <= 3)

        # Test if the average skill is as expected
        expected_average_skill = 2
        actual_average_skill = sum(skills) / len(skills)
        self.assertAlmostEqual(actual_average_skill, expected_average_skill, places=1)
        #Be aware it is hard to determine how close the average will get, the more
        #firefighter the closer I can get


#From here and down Firecrew tests

    def test_update_locations(self):
        #tests if locations change between rounds, could be done better
        
        first_locations = self.mock_crew._locations
        
        for fireman in self.mock_crew._crew:
            fireman.set_location(1)

        self.mock_crew.update_locations()
        
        self.assertNotEqual(first_locations, self.mock_crew._locations)
        self.assertEqual(self.mock_crew._locations, [1, 1, 1, 1, 1])
        
      
    #there will be several tests for firefighter_round
    def test_firefighter_round(self):
        #if there are no fires all firefighters should move at random
        
        #make sure there are no fires
        for node in self.mock_graph.get_nodes_instance():
            patch = self.mock_graph.get_node_patch(node)
            self.assertFalse(patch.getter_ablaze())
            
        first_locations = self.mock_crew._locations
        
        self.mock_crew.firefigher_round()
        self.mock_crew.update_locations()
        second_locations = self.mock_crew._locations
        
        self.assertNotEqual(first_locations, second_locations)
        
        for elem in second_locations:
            self.assertIn(elem, self.mock_graph.get_nodes())
        
        #All firefighters are at node 1, we set this ablaze 
        for firefighter in self.mock_crew._crew:
            firefighter.set_location(1)
        self.mock_graph.get_node_patch(1).setter_ablaze(True)
        self.assertTrue(self.mock_graph.get_node_patch(1).getter_ablaze())
        
        #when each firefighter takes an action, 3 should stay and extinguish and 2 should move
        self.mock_crew.firefigher_round()
        self.mock_crew.update_locations()
        
        first_3_locations = self.mock_crew._locations[0:3] #first 3 elements 
        last_2_locations = self.mock_crew._locations[3:]
        
        self.assertFalse(self.mock_graph.get_node_patch(1).getter_ablaze())
        self.assertEqual(first_3_locations, [1, 1, 1])
        self.assertNotEqual(last_2_locations, [1, 1])
        
        for elem in last_2_locations:
            self.assertIn(elem, self.mock_graph.get_nodes())

        

#test firecrew, what is firecrew is size 0

if __name__ == "__main__":
    unittest.main()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    