from user_interface import UserInterface, UserQuitException
import unittest
from unittest.mock import patch
class TestUserInterface(unittest.TestCase): # we inherit from unittest.TestCase
    def setUp(self):
        self.ui = UserInterface()

    def test_exception_raised(self):
        # this catches the exception
        with self.assertRaises(UserQuitException):
            # this raises the UserQuitException
            raise UserQuitException("This is a test message")

    @patch('builtins.input', side_effect=['random_generation']) # brackets because it is an itterable of characters
    def test_set_graph_random_generation(self, mock_input):
        self.ui.set_graph_method()
        self.assertEqual(self.ui.graph, "random_generation")

    @patch('builtins.input', side_effect=["file"])
    def test_set_graph_file(self, mock_input):
        self.ui.set_graph_method()
        self.assertEqual(self.ui.graph, "file")

    @patch('builtins.input', side_effect=['invalid_choice', 'random_generation'])
    def test_set_graph_invalid_then_valid(self, mock_input):
        self.ui.set_graph_method()
        self.assertEqual(self.ui.graph, 'random_generation')

    @patch('builtins.input', side_effect=['invalid_choice', 'q'])
    def test_set_graph_invalid_input_then_quit(self, mock_input):
        with self.assertRaises(UserQuitException):
            self.ui.set_graph_method()
            
    @patch('builtins.input', side_effect=['random_generation'])   
    def test_get_graph_after_setting(self, mock_input):
        self.ui.set_graph_method()
        result = self.ui.get_graph_method()
        self.assertEqual(result, "random_generation")
        
    @patch('builtins.input', side_effect=['q'])   
    def test_load_graph_from_file_quit(self, mock_input):
        with self.assertRaises(UserQuitException):
            self.ui.load_graph_from_file()

    @patch('builtins.input', side_effect=['valid\file_path\file.dat'])
    @patch('os.path.exists', return_value=True)
    @patch('os.path.getsize', return_value=42)
    @patch('builtins.open', create=True, new_callable=unittest.mock.mock_open, read_data='#jk\n1,\njjk')
    def test_load_graph_from_file_invalid_file(self, mock_input, mock_exists, mock_getsize, mock_open):
        self.ui.file_content = []
        with self.assertRaises(UserQuitException):
            self.ui.load_graph_from_file()
        
    @patch('builtins.input', side_effect=['valid2\\file_path2\\file2.dat'])
    @patch('os.path.exists', return_value=True)
    @patch('os.path.getsize', return_value=42)
    @patch('builtins.open', create=True, new_callable=unittest.mock.mock_open, read_data='#this line should be ignored\n0,1\n1,2\n2,3\n3,0\n6,0')
    @patch('user_interface.graph_helper.edges_planar', return_value=True)
    def test_load_graph_from_file_invalid_file2(self, mock_input, mock_exists, mock_getsize, mock_open, mock_edges_planar):
        self.ui.file_content = [[0, 1], [1, 2], [2, 3], [3, 0], [6, 0]]
        # Set up of the function
        with self.assertRaises(UserQuitException):
            self.ui.load_graph_from_file()

    @patch('builtins.input', side_effect=['valid\\file_path\\file.dat'])
    @patch('os.path.exists', return_value=True)
    @patch('os.path.getsize', return_value=42)
    @patch('builtins.open', create=True, new_callable=unittest.mock.mock_open, read_data='#this line should be ignored\n0,1\n1,2\n2,3\n3,0')
    @patch('user_interface.graph_helper.edges_planar', return_value=True)
    def test_load_graph_from_file_valid_file(self, mock_input, mock_exists, mock_getsize, mock_open, mock_edges_planar):
        self.ui.file_content = [[0, 1], [1, 2], [2, 3], [3, 0]]
        expected_tuples = [(0, 1), (0, 3), (1, 2), (2, 3)]
        # Set up of the function
        self.assertEqual(self.ui.load_graph_from_file(), expected_tuples)

    @patch('builtins.input', side_effect=['non_planar_file_path.dat'])
    @patch('os.path.exists', return_value=True)
    @patch('os.path.getsize', return_value=60)  
    @patch('builtins.open', create=True, new_callable=unittest.mock.mock_open, read_data='#non-planar graph data\n0,1\n1,2\n2,3\n3,0\n4,0\n5,4')
    @patch('user_interface.graph_helper.edges_planar', return_value=False)
    def test_load_non_planar_graph_from_file(self, mock_input, mock_exists, mock_getsize, mock_open, mock_edges_planar):
        self.ui.file_content = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 0], [5, 4]]

        with self.assertRaises(UserQuitException):
            self.ui.load_graph_from_file()

    @patch('builtins.input', side_effect=['non_connected_file_path.dat'])
    @patch('os.path.exists', return_value=True)
    @patch('os.path.getsize', return_value=60)
    @patch('builtins.open', create=True, new_callable=unittest.mock.mock_open, read_data='#non-connected graph data\n0,1\n1,2\n3,4\n4,5\n')
    @patch('user_interface.graph_helper.edges_planar', return_value=True)
    def test_load_non_connected_graph_from_file(self, mock_input, mock_exists, mock_getsize, mock_open, mock_is_connected):
        self.ui.file_content = [[0, 1], [1, 2], [3, 4], [4, 5]]

        # Call the method to test
        with self.assertRaises(UserQuitException):
            self.ui.load_graph_from_file()        

    @patch('builtins.input', side_effect=['5']) #brackets are technically not necesarry here, because it is not an itterable of characters. but we do it for consistency
    def test_set_minpoints_valid_input(self, mock_input):
        self.ui.set_minpoints()

        self.assertEqual(self.ui.minimum_points, 5)

    @patch('builtins.input', side_effect=['3', 'q'])
    def test_set_minpoints_invalid_then_quit(self, mock_input):
        with self.assertRaises(UserQuitException):
            self.ui.set_minpoints()

    @patch('builtins.input', side_effect=['6'])
    def test_get_minpoints(self, mock_input):
        self.ui.set_minpoints()

        self.assertIs(type(self.ui.minimum_points), int)
        
    @patch('builtins.input', side_effect=['all_rocks', '3', '2', '0,9', '0,3', '0,1', '5'])
    def test_set_parameters_all_rocks_valid_values(self, mock_input):
        # we have to set number of nodes before running
        number_of_nodes = 4
        self.ui.set_parameters(number_of_nodes)
        # Assert the different inputs
        self.assertEqual(self.ui.tree_pop, 2)
        self.assertEqual(self.ui.firefighters, 3)
        self.assertEqual(self.ui.skill_level, 2)
        self.assertEqual(self.ui.Ignition, 0.9)
        self.assertEqual(self.ui.Transmission, 0.3)
        self.assertEqual(self.ui.Respawn, 0.1)
        self.assertEqual(self.ui.Itteration_steps, 5)


    @patch('builtins.input', side_effect=['random', '3', '2','q'])
    def test_set_parameters_mixed_quit(self, mock_input):
        number_of_nodes = 4
        with self.assertRaises(UserQuitException):
            self.ui.set_parameters(number_of_nodes)
        self.assertEqual(self.ui.tree_pop, 3)
        self.assertEqual(self.ui.firefighters, 3)
        self.assertEqual(self.ui.skill_level, 2)


    @patch('builtins.input', side_effect=['skibidy', 'all_wood', 'GYAT', '4', 'no cap', '3', 'stop', '0,4', 'plz', '0,3', 'alpha', '0.8', 'gen', '9'])
    def test_set_parameters_with_invalid_input(self, mock_input):
        number_of_nodes = 4
        self.ui.set_parameters(number_of_nodes)

        self.assertEqual(self.ui.tree_pop, 1)
        self.assertEqual(self.ui.firefighters, 4)
        self.assertEqual(self.ui.skill_level, 3)
        self.assertEqual(self.ui.Ignition, 0.4)
        self.assertEqual(self.ui.Transmission, 0.3)
        self.assertEqual(self.ui.Respawn, 0.8)
        self.assertEqual(self.ui.Itteration_steps, 9)
        
    @patch('builtins.input', side_effect=['0.4'])
    def test_set_ignition(self, mock_input):
        self.ui.set_ignition()
        self.assertEqual(self.ui.Ignition, 0.4)

    @patch('builtins.input', side_effect=['RIZZ', 'q'])
    def test_set_ignition_with_invalid_input_and_quit(self, mock_input):
        with self.assertRaises(UserQuitException):
            self.ui.set_ignition()

    @patch('builtins.input', side_effect=['Fanum', 'tax', '0,9'])
    def test_set_transmission_with_invalid_input(self, mock_input):
        self.ui.set_transmission()
        self.assertEqual(self.ui.Transmission, 0.9)

    @patch('builtins.input', side_effect=['Rizzler', '1,00001', '0,3'])
    def test_set_respawn_with_invalid_input(self, mock_input):
        self.ui.set_forest_respawn()
        self.assertEqual(self.ui.Respawn, 0.3)

    def test_get_parameters(self):
        self.ui.tree_pop = 1
        self.ui.firefighters = 3
        self.ui.skill_level = 2
        self.ui.Itteration_steps = 10
        self.ui.Ignition = 0.6
        self.ui.Transmission = 0.3
        self.ui.Respawn = 0.2

        result = self.ui.get_parameters()

        expected_result = (1, 3, 2, 10, 0.6, 0.3, 0.2)
        self.assertEqual(result, expected_result)

if __name__ == '__main__':
    unittest.main()
